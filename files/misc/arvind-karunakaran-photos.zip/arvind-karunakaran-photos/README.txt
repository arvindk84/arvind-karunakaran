Arvind Karunakaran: headshots and event photos for event programs and listings

Headshots
  headshot-outdoor-1100x1647.jpg
  headshot-studio-720x900.jpg
  headshot-closeup-640x640.jpg

Event photos
  event-federal-reserve-bank-of-new-york-panel-2026.jpg  (Governance & Culture Reform Conference, Oct 6, 2026)
  event-imagination-in-action-ai-summit-at-google-2026.jpg  (Panel: "Who Does the Work Now," Sept 14, 2026)
  event-executive-briefing-sydney.jpg
  event-executive-session.jpg

Bios, an emcee introduction, and the speaker one-sheet:
https://www.arvindkarunakaran.com/speaking.html#bio

Larger originals: arvindka@stanford.edu
